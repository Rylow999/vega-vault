#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sddf_core.py — nucleo numerico de la curvatura espectral

    G[u] = INT [ d(ln E)/d(ln k) ]^2  d(ln k)

Replica bit a bit el esquema de main.rs (derivadas centradas en el interior,
forward/backward en los bordes, trapecio sobre ln k) y agrega:

  * truncate_by_slope        corte por desviacion de pendiente (v1)
  * truncate_by_slope_interp corte INTERPOLADO en ln k (v2, recomendado):
                             elimina el error de cuantizacion del corte,
                             que es la fuente dominante de error en grillas
                             de pocos miles de puntos
  * truncate_by_x            corte directo en k*eta = x_c (si se conoce nu)
  * g_normalizado            G* / ln(k_c/k_min) = <s^2>, invariante de Re
  * q_efectivo               exponente espectral implicado por <s^2>

El piso absoluto 1e-30 del lector original se conserva SOLO como opcion
(floor=1e-30) para poder reproducir el bug historico.
"""
import numpy as np

S_K41 = -5.0 / 3.0


# ----------------------------------------------------------------------
# Lectura
# ----------------------------------------------------------------------
def read_spectrum_csv(path, floor=None):
    """
    Lee un CSV 'k,E(k)[,k_eta]'. Ignora comentarios '#' y la cabecera.
    floor=1e-30 reproduce el piso del lector original (bug historico).
    floor=None descarta los puntos con E<=0 o no finito, que es lo correcto.
    Devuelve (k, E, n_descartados).
    """
    k_vec, e_vec, dropped = [], [], 0
    with open(path, "r") as fh:
        for line in fh:
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            parts = s.split(",")
            if len(parts) < 2:
                continue
            try:
                k = float(parts[0].strip())
                e = float(parts[1].strip())
            except ValueError:
                continue  # cabecera
            if floor is not None:
                k_vec.append(k)
                e_vec.append(e if e > floor else floor)
            else:
                if np.isfinite(k) and k > 0 and np.isfinite(e) and e > 0:
                    k_vec.append(k)
                    e_vec.append(e)
                else:
                    dropped += 1
    return np.asarray(k_vec, float), np.asarray(e_vec, float), dropped


def read_meta(path):
    """Extrae los '# clave=valor' de la cabecera (nu, eta, beta, C_k, ...)."""
    meta = {}
    with open(path, "r") as fh:
        for line in fh:
            s = line.strip()
            if not s.startswith("#"):
                if s and not s.startswith("#"):
                    break
                continue
            if "=" in s:
                kk, vv = s[1:].split("=", 1)
                meta[kk.strip()] = vv.strip()
    return meta


# ----------------------------------------------------------------------
# Nucleo
# ----------------------------------------------------------------------
def local_slope(k, e):
    """Pendiente log-log local. Identico esquema que main.rs."""
    lk, le = np.log(np.asarray(k, float)), np.log(np.asarray(e, float))
    n = len(lk)
    d = np.zeros(n)
    if n < 2:
        return d
    d[1:-1] = (le[2:] - le[:-2]) / (lk[2:] - lk[:-2])
    d[0] = (le[1] - le[0]) / (lk[1] - lk[0])
    d[-1] = (le[-1] - le[-2]) / (lk[-1] - lk[-2])
    return d


def compute_spectral_curvature(k, e):
    """G[u] por trapecio sobre ln k. Identico a main.rs."""
    k = np.asarray(k, float)
    if len(k) < 3:
        return 0.0
    lk = np.log(k)
    d = local_slope(k, e)
    return float(np.trapezoid(d ** 2, lk))


# ----------------------------------------------------------------------
# Truncados
# ----------------------------------------------------------------------
def truncate_tail(k, e, rel_thresh=1e-6):
    """Corte por amplitud relativa. DEPRECADO: el exponente que se ajuste
    despues depende del umbral (ver 03_sensibilidad_umbral.csv)."""
    k, e = np.asarray(k, float), np.asarray(e, float)
    if len(k) < 3:
        return k, e, 0
    below = np.nonzero(e < rel_thresh * e[0])[0]
    if len(below) == 0:
        return k, e, 0
    cut = max(int(below[0]), 3)
    return k[:cut], e[:cut], len(k) - cut


def truncate_by_slope(k, e, delta=0.5, s_ref=S_K41):
    """Corte por desviacion de pendiente, en el primer punto de grilla."""
    k, e = np.asarray(k, float), np.asarray(e, float)
    if len(k) < 3:
        return k, e, 0, False
    s = local_slope(k, e)
    bad = np.nonzero(np.abs(s - s_ref) > delta)[0]
    if len(bad) == 0:
        return k, e, 0, True
    cut = int(bad[0])
    ok = cut >= 3          # bandera: si es False, el resultado NO significa nada
    cut = max(cut, 3)
    return k[:cut], e[:cut], len(k) - cut, ok


def truncate_by_slope_interp(k, e, delta=0.5, s_ref=S_K41):
    """
    Igual que el anterior pero con el punto de corte INTERPOLADO linealmente
    en (ln k, s). Agrega el nodo exacto donde |s - s_ref| = delta, con E
    interpolada en log-log. Quita el error de cuantizacion del corte.
    Devuelve (k, e, n_cortados, ok, k_corte).
    """
    k, e = np.asarray(k, float), np.asarray(e, float)
    if len(k) < 3:
        return k, e, 0, False, np.nan
    s = local_slope(k, e)
    dev = np.abs(s - s_ref)
    bad = np.nonzero(dev > delta)[0]
    if len(bad) == 0:
        return k, e, 0, True, float(k[-1])
    j = int(bad[0])
    if j < 3:
        return k[:3], e[:3], len(k) - 3, False, float(k[2])
    lk = np.log(k)
    d0, d1 = dev[j - 1], dev[j]
    w = 0.0 if d1 == d0 else (delta - d0) / (d1 - d0)
    w = min(max(w, 0.0), 1.0)
    lkc = lk[j - 1] + w * (lk[j] - lk[j - 1])
    lec = np.log(e[j - 1]) + w * (np.log(e[j]) - np.log(e[j - 1]))
    k_new = np.concatenate([k[:j], [np.exp(lkc)]])
    e_new = np.concatenate([e[:j], [np.exp(lec)]])
    return k_new, e_new, len(k) - j, True, float(np.exp(lkc))


def truncate_by_x(k, e, eta, x_c):
    """Corte directo en k*eta = x_c (requiere conocer nu). Interpolado."""
    k, e = np.asarray(k, float), np.asarray(e, float)
    k_c = x_c / eta
    if k_c >= k[-1]:
        return k, e, 0, True, float(k[-1])
    j = int(np.searchsorted(k, k_c))
    if j < 3:
        return k[:3], e[:3], len(k) - 3, False, float(k[2])
    lk = np.log(k)
    w = (np.log(k_c) - lk[j - 1]) / (lk[j] - lk[j - 1])
    lec = np.log(e[j - 1]) + w * (np.log(e[j]) - np.log(e[j - 1]))
    k_new = np.concatenate([k[:j], [k_c]])
    e_new = np.concatenate([e[:j], [np.exp(lec)]])
    return k_new, e_new, len(k) - j, True, float(k_c)


# ----------------------------------------------------------------------
# Estimadores derivados
# ----------------------------------------------------------------------
def g_normalizado(k, e):
    """
    <s^2> = G / ln(k_max/k_min). Invariante de Re: no cuenta decadas,
    mide la forma del espectro. Para K41 puro da 25/9 = 2.7778.
    """
    k = np.asarray(k, float)
    if len(k) < 3:
        return np.nan
    span = np.log(k[-1] / k[0])
    if span <= 0:
        return np.nan
    return compute_spectral_curvature(k, e) / span


def q_efectivo(k, e):
    """Exponente espectral efectivo -q implicado por <s^2>: q = sqrt(<s^2>)."""
    gn = g_normalizado(k, e)
    return np.nan if not np.isfinite(gn) else np.sqrt(gn)


def g_original_con_bug(path):
    """G[u] tal como lo daba el lector original (piso absoluto 1e-30)."""
    k, e, _ = read_spectrum_csv(path, floor=1e-30)
    return compute_spectral_curvature(k, e), int((e <= 1e-30).sum())
