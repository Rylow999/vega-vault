# DSCN-G Language Engine — Estado y Análisis (actualizado 2026-07-25)

Proyecto de Luciano. Objetivo: determinar si DSCN-G puede ser sustrato cognitivo
de un motor de lenguaje, terminando en un decodificador L2 rústico y una
"pseudoAGI" de laboratorio (sustrato neuro-simbólico, no reemplazo de LLM).

Todos los experimentos son Python puro (sin numpy). Corpus: Don Quijote
(Project Gutenberg, dominio público) salvo indicado. Paper GPT-1 en gpt1_paper.pdf.

## RESULTADOS MEDIDOS (datos duros)

| Exp | Pregunta | Resultado | Veredicto |
|-----|----------|-----------|-----------|
| v0.1 | ¿El grafo colapsa? | N* satura ~4.5 (sublineal) | ✓ working memory, no masa |
| v0.2 | ¿Colapso paramétrico? | N* sube con K/θ (3.8→166) pero sublineal | ✓ paramétrico, no estructural |
| v0.3 retrieval | ¿El grafo entiende? | recupera 100% (norma) / 91% (bits) a 256 conc. | ✓ entiende |
| v0.3 REAL v2 | ¿Hibernar preserva masa? | retención 100% (N_total=N_init, working set ~4.5) | ✓ VALIDA DB semántica |
| v0.4 | β contextual (Pandora) | N*=5.0 vs 5.2 (ruido, no aporta) | ✗ ρ no se activa en repr. rústica |
| v0.5 | L2 decoder retrieve | "gato"→"gato" OK | ✓ |
| v0.5b | L2 rompe loop | "el casa el casa"→"el roja la corre..." (0 rep. ady.) | ✓ loop roto |
| v0.6a | next-token (corpus real) | accuracy 0.45%→10.11% | ✓ APRENDE |
| v0.6b | dolor post-hoc (RL) | mejora 0.0 | ✗ castigo llega tarde |
| v0.6b-bis | dolor Q-learning en decisión | mejora -0.0012 (ruido) | ✗ redundante en supervisado |
| v0.7 | contexto promedio | 5.89% (peor que 10.11%) | ✗ pisa nodos |
| v0.7-bis | contexto separado | 0.49% | ✗ contamina omega |
| v0.7-final | trigrama limpio (tabla) | 3.85% | ✗ disperso, no escala |
| v0.8 | atención rústica | 8.64% (peor que 10.11%) | ✗ no supera bigrama (vocab chico) |
| v0.9a | dolor señal evasión (corpus) | 0.0149→0.0149 (medido mal) | ✗ diseño: sobre corpus, no generación |
| v0.9a-bis v1/v2 | dolor en generación (repetición) | 0.0→0.0 (no repite sistemáticamente) | ✗ crítico externo no medible aquí |
| v0.9b | etiquetas que MUTAN por uso | 92.67% accuracy vs verdad corpus | ✓ etiqueta emerge de dinámica |
| v0.9c | subsistencia global (dolor interno) | G 0.0→1.0 (el dolor salva al grafo) | ✓ DOLOR EMERGENTE validado |
| v0.10 | persistencia score híbrido (SynapticCache 2.1+2.4) | N_active=N_total (memoria VIVA por relevancia) | ~ política distinta a hibernado |

## MAPA HONESTO DE CAPACIDADES
- FUERTE en lo LOCAL: recupera conceptos, aprende next-token, masa persistente
  (hibernado), categoriza por uso (etiquetas mutantes 92%), se autopreserva por
  dolor interno (G 0→1).
- DÉBIL en lo que requiere ESCALA/ATENCIÓN: contexto largo (con vocab chico no
  aporta), abstracción (dimensiones por concepto, pendiente), entorno de
  consecuencia (dolor interno de afinidad, no de mundo real).

## PIEZAS CENTRALES CONFIRMADAS HOY
1. MEMORIA MASIVA PERSISTENTE (v0.3 REAL): no olvida, duerme lo que no usa.
2. CATEGORIZACIÓN EMERGENTE (v0.9b): deduce sustantivo/verbo por su dinámica.
3. DOLOR INTERNO QUE OBLIGA A CAMBIAR (v0.9c): el grafo se autopreserva.

## PATRONES SynapticCache INTEGRADOS
- 2.1 score evict híbrido → v0.10 (criterio de desalojo, da memoria viva)
- 2.2 omega_root (centroide por V) → v0.10
- 2.3 umbral por distancia → pendiente usar
- 2.4 fallback LRU → v0.10 (si demonio muere)
- 2.5 Modo AUDIT → v0.9a (observar antes de actuar)

## ROADMAP
- Hecho: v0.1..v0.3, v0.5/0.5b, v0.6a, v0.9b, v0.3 REAL (hibernado), v0.9c
- Descartados por diseño (no concepto): v0.9a/v0.9a-bis (crítico externo no medible), v0.4 (β_eff no se activa)
- Siguiente fase: v0.11 (abstracción: dimensiones por concepto), v0.12 (atención real con vocab grande), v0.13 (entorno / dolor de consecuencia)

## CONCLUSIÓN
El grafo DSCN-G rústico es un sustrato neuro-simbólico con memoria masiva
persistente (hibernado), categorización emergente y autopreservación por dolor
interno. Aprende de corpus real y recupera conceptos. Para una pseudoAGI faltan:
abstracción por dimensiones (v0.11), atención real con vocab grande (v0.12) y
entorno de consecuencia (v0.13). Todo medible, de a poco. Tu marco de
subsistencia y DB semántica se confirmó empíricamente.

## NOTA DE RIGOR
- v0.4 y v0.9a/abis se reportan como "no medibles / no aportan" con la razón
  técnica, no como éxitos. El rigor importa más que la ambición de claims.
- Lenguaje es RÚSTICO: 10% next-token no es "entender español", es la base.
- El grafo en Python puro en telefonito es lento (N=1000 tarda minutos). Para
  vocab real (50k) necesita numpy/GPU, que acá no tenemos.
